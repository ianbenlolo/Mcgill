#ifndef Consumer_h
#define Consumer_h


void consumer();

#endif
