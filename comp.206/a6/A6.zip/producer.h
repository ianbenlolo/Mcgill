#ifndef Producer_h
#define Producer_h


void producer();


#endif
