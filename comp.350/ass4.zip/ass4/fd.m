function y=fd(x)
y=3*x^2-4*x+1;